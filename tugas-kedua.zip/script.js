const { createApp } = Vue;

createApp({
    data() {
        return {
            title: "Aplikasi Vue: Studi Kasus Tugas Kedua",
            isVisible: true,
            imageSrc: "https://vuejs.org/images/logo.png",
            altText: "Logo Vue",
            counter: 0,
            nama: ""
        };
    },
    methods: {
        toggleVisible() {
            this.isVisible = !this.isVisible;
        },
        incrementCounter() {
            this.counter++;
        },
        submitForm() {
            alert("Form disubmit untuk " + this.nama);
        }
    }
}).mount("#app");
