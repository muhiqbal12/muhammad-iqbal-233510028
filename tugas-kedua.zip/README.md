# Tugas Kedua - Vue

## Fitur
- Declarative Rendering
- Attribute Bindings
- Event Listeners
- Form Bindings
- Conditional Rendering

## Deploy
1. Push ke GitHub
2. Deploy ke Vercel atau Netlify
